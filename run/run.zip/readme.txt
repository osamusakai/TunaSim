catsim.dat - simulator scenario (input data for simulation)
catsim.frq - simulated data set
graph.frq  - fit to catsim.frq data set
04.fit     - fit file
